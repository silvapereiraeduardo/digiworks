function saveOptions() {
    var url = document.getElementById('jira-url').value;
    var togglApyKey = document.getElementById('toggl-api-key').value;
    var comment = document.getElementById('log-comment').value;
    var commentReplace = document.getElementById('log-comment-replace').value;
    var jiraUserEmail = document.getElementById('jira-user-email').value;
    var merge = document.getElementById('merge-entries').checked;
    var jumpToToday = document.getElementById('jump-to-today').checked;
    var showDayTotal = document.getElementById('show-day-total').checked;
    chrome.storage.sync.set({
        url: url,
        togglApyKey: togglApyKey,
        comment: comment,
        commentReplace: commentReplace,
        jiraUserEmail: jiraUserEmail,
        merge: merge,
        jumpToToday: jumpToToday,
        showDayTotal: showDayTotal
    }, function () {
        var status = document.getElementById('status');
        status.style = 'display: block';
        status.textContent = 'CONFIGURAÇÕES ATUALIZADAS';
        setTimeout(function () {
            status.style = 'display: none';
        }, 5000);
    });
}

function restoreOptions() {
    chrome.storage.sync.get({
        url: 'https://digifred.atlassian.net',
        togglApyKey: '',
        comment: '',
        commentReplace: '',
        jiraUserEmail: '',
        merge: false,
        jumpToToday: false,
        showDayTotal: true
    }, function (items) {
        document.getElementById('jira-url').value = items.url;
        document.getElementById('toggl-api-key').value = items.togglApyKey;
        document.getElementById('log-comment').value = items.comment;
        document.getElementById('log-comment-replace').value = items.commentReplace;
        document.getElementById('jira-user-email').value = items.jiraUserEmail;
        document.getElementById('merge-entries').checked = items.merge;
        document.getElementById('jump-to-today').checked = items.jumpToToday;
        document.getElementById('show-day-total').checked = items.showDayTotal;
    });
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);
